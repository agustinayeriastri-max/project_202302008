from django.apps import AppConfig

class PembelianConfig(AppConfig):
    name = 'pembelian'
