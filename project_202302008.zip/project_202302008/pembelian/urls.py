from django.urls import path
from . import views

urlpatterns = [
    path('', views.welcome_page, name='welcome_page'),
    path('dashboard/', views.dashboard, name='dashboard'),

    # Pembelian
    path('pembelian/', views.form_pembelian, name='form_pembelian'),
    path('pembelian/edit/<int:id>/', views.edit_pembelian, name='edit_pembelian'),
    path('pembelian/hapus/<int:id>/', views.hapus_pembelian, name='hapus_pembelian'),

    # Transaksi Multi-Barang
    path('transaksi/tambah/', views.tambah_transaksi, name='tambah_transaksi'),
    path('transaksi/', views.list_transaksi, name='list_transaksi'),
    path('transaksi/detail/<int:id>/', views.detail_transaksi, name='detail_transaksi'),
    path('transaksi/hapus/<int:id>/', views.hapus_transaksi, name='hapus_transaksi'),

    # Laporan
    path('laporan/', views.laporan_pembelian, name='laporan_pembelian'),
    path('laporan/cetak/', views.cetak_pdf, name='cetak_pdf'),

    # Barang & Kategori
    path('barang/stok/', views.daftar_stok_barang, name='stok_barang'),
    path('barang/tambah/', views.tambah_barang, name='tambah_barang'),
    path('barang/kategori/<int:kategori_id>/', views.barang_per_kategori, name='barang_per_kategori'),
    path('kategori/', views.kategori_list, name='kategori_list'),

    # AJAX
    path('ajax/harga-barang/', views.get_harga_barang, name='get_harga_barang'),
    path('ajax/barang-by-supplier/', views.get_barang_by_supplier, name='get_barang_by_supplier'),
]
